package com.henry;

import com.google.cloud.functions.BackgroundFunction;
import com.google.cloud.functions.Context;
import com.henry.dto.PubSubMessage;

import java.util.Base64;
import java.util.logging.Logger;

public class Backfill implements BackgroundFunction<PubSubMessage> {
  private static final Logger logger = Logger.getLogger(Backfill.class.getName());

  private int counter;

  @Override
  public void accept(PubSubMessage message, Context context) {
    String data = message.getData() != null
      ? new String(Base64.getDecoder().decode(message.getData()))
      : "Hello, World";
    logger.info(data + " from pub sub");

    try {
      // Handle incoming Pub/Sub message
      logger.info("Processing processBatch********************** ");

      // Trigger batch processing
      processBatch();
    } catch (Exception e) {
      logger.severe("Error processing Pub/Sub message: " + e.getMessage());
    }
  }

  private void processBatch() {

  }

}
