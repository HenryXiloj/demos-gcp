package com.henry.dto;

import java.util.Map;


public class PubSubMessage {

    String data;
    Map<String, String> attributes;
    String messageId;
    String publishTime;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
